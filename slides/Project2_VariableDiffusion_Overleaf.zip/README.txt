Overleaf: New Project > Upload Project > select this ZIP.
Main document: main.tex. Compiler: pdfLaTeX. No shell escape required.
Edit author names in the main.tex preamble. All referenced figures are included.
